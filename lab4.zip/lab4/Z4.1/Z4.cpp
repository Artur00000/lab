﻿//7.	Описати рекурсивну функцію GCD(A, B) цілого типу
//, яка знаходить найбільший спільний дільник(НСД, greatest common divisor) двох цілих позитивних чисел A і B,
//використовуючи алгоритм Евкліда :
//НСД(A, B) = НСД(B, A mod B), B ≠ 0; НСД(A, 0) = A,
//де «mod» позначає операцію взяття залишку від ділення.
//За допомогою цієї функції знайти НСД(A, B), НCД(A, C),
//НCД(A, D), якщо дано числа A, B, C, D.


#include <iostream>
using namespace std;

int GCD(int A, int B)
{
	int a, b;
	a = A;
	b = B;
	for (;;) {
		if (a == b) {

			break;
			return a;
		}
		else {
			if (a>b) {
				a = a - b;

			}
			else {

				b = b - a;
			}
		}
	}






}
int main()
{
	setlocale(LC_ALL, "Rus");
	int A , B[3],c[3] ;
	cin >> A;
	for (int i = 0; i < 3;i++) {
		cin >> B[i];
		c[i] = GCD(A, B[i]);
	}
	/*for (int i = 0; i < 2; i++) {
		int g;
		if (c[i]<c[i+1]) {
			g = c[i];
			c[i] = c[i +1 ];
			c[i + 1] = g;
		}
	}
	for (int i = 0; i < 3; i++) {
		cout << c[i] << endl;
	}*/
	for (int i = 0; i < 3; i++) {
		cout << c[i] << endl;
	}
	system("pause");
	return	0;

}

