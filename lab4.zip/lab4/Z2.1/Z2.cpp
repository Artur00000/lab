﻿/*3. Описати рекурсивну функцію PowerN(X, N) дійсного типу, яка знаходить значення N - го степеня числа X за формулами :
X 0 = 1,
X N = (X N / 2) 2 при парних N> 0,
X N = X · X N - 1 при непарних N> 0,
X N = 1 / X - N при N <0
(X ≠ 0 - дійсне число, N - ціле; у формулі для парних N повинна використовуватися операція цілочисельного ділення).За допомогою цієї функції знайти значення X N для даного X при п'яти даних значеннях N.
Клименко Артур
*/
#include <iostream>
using namespace std;
const int n = 5;

double  PowerN(int N, double X)
{
	float l = 1;

	if (N < 0)
	{
		l = 1 / pow(X, -N);

	}
	else {
		if (N & 1)
		{
			l = pow(X, N - 1)*X;

		}
		else {

			l = pow(pow(X, N / 2), 2);
		}

	}


	return l;

}
int main()
{
	setlocale(LC_ALL, "Rus");
	int N[n];
	double X;

	cout << "Введiть п'яти чисел для обчислення:";

	cin >> N[0] >> N[1] >> N[2] >> N[3] >> N[4] >> X;
	cout << "Рiшення:";
	for (int i = 0; i < 5; i++) {

		cout << PowerN(N[i], X) << endl;

	}

	system("pause");
	return	0;

}


