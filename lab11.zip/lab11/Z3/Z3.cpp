﻿//3.	Дана матриця розміру M × N.Поміняти місцями стовпці, що містять мінімальну і максимальну суму елементів.

#include <iostream>
using namespace std;
int main() {
	const int n = 10, m = 10;
	int max, min;
	int maxi, mini,k;
	int masiv[n][m];
	int sum[n];
	for (int i = 0; i < n; i++)
	{
		
		for (int j = 0; j < m; j++)
		{

			masiv[i][j] = rand() % 11;
			
			cout << masiv[i][j] << " ";
		}
		cout << endl;
	}

	for (int i = 0; i < n; i++)
	{
		sum[i] = 0;
		for (int j = 0; j < m; j++) {

			sum[i] += masiv[j][i];
		}
	}
	min = sum[0];
	max= sum[0];
	for (int j = 1; j < m; j++) {
		if(min< sum[j]){
		
		
		}
		else {
			min = sum[j];
			mini = j;
		}
		if (max > sum[j]) {


		}
		else {
			max = sum[j];
			maxi = j;
		}
	}

			
			for (int j = 0; j < m; j++) {
				cout << masiv[j][mini] << "{- ";
				cout << masiv[j][maxi] << "(-";
				k = masiv[j][mini];
				masiv[j][mini] = masiv[j][maxi];
				masiv[j][maxi] = k;
				
			}
			cout << endl;
			for (int j = 0; j < m; j++) {
				cout << masiv[j][mini] << "{- ";
				cout << masiv[j][maxi] << "(-";
			}
		
			cout << endl;
			for (int i = 0; i < n; i++)
			{

				for (int j = 0; j < m; j++)
				{

					

					cout << masiv[i][j] << " ";
				}
				cout << endl;
			}

	/*cout << maxi << "{ ";
	cout << mini << "( "<<endl;
	cout << max << "{- ";
	cout << min << "(-" << endl;*/
	system("Pause");
	return 0;
}