﻿
//1.	Дана матриця розміру M × N.Заповнити її випадковими числами з діапазону від 0 до 10.
//Перший раз вивести елементи матриці у звичайному порядку(по рядкам).Другий раз вивести елементи матриці в наступному порядку :
//перший рядок зліва направо, другий рядок справа наліво, третій рядок зліва направо, четвертий рядок справа наліво і т.д.


#include <iostream>
using namespace std;
int main() {
	const int n = 10,m=10;

	int masiv[n][m];
	
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			masiv[i][j] = rand()%11;
			cout << masiv[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
	int h;
	for (int i = 0; i < n; i++)
	{
		h = i % 2;

		if (h==0) {

		for (int j = 0; j < n; j ++)
		{
			
			cout << masiv[i][j] << " ";
		}
		}
		else {
			for (int j = n-1; j >= 0; j --)
			{
				
				cout << masiv[i][j] << " ";
			}
		}
		cout << endl;
	}
	system("Pause");
	return 0;
}