﻿//2.	Дана матриця розміру M × N.Знайти кількість її рядків, елементи яких впорядковані за зростанням.


#include <iostream>
using namespace std;
int main() {
	const int n = 10, m = 10;

	int masiv[n][m];

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			masiv[i][j] = rand() % 11;
			
		}
		cout << endl;
	}
	cout << endl;
	int max = masiv[0][0];
	
	for (int h = 0; h < m;h++) {
	//int h = 0;
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j <n  - i - 1; j++) {
				if (masiv[h][j] > masiv[h][j+1])
				{
					max = masiv[h][j];

					masiv[h][j] = masiv[h][j+1];
					masiv[h][j+1] = max;
				}

			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			cout << masiv[i][j] << " ";
		}
		cout << endl;
	}
	system("Pause");
	return 0;
}