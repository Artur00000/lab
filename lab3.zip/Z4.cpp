﻿/*
№3
№8
Описати функцію Arctg1 (x, ε) дійсного типу (параметри x, ε - дійсні, | x | <1, ε> 0), знаходить наближене значення функції arctg (x):
arctg (x) = x - x^3 / 3 + x^5 / 5 - ... + (-1)^n · x^(2 · n + 1) / (2 · n + 1) + ....
В сумі враховувати всі складові, модуль яких більше ε. За допомогою Arctg1 знайти наближене значення arctg (x) для даного x при шести даних ε.


Клименко Артур
*/



#include <iostream>
using namespace std;
double xstepeni(double x,int st) {

	double e=1;
	
	for (int i = 0; i < st;i++) {
		e = e * x;
	}
	return	e;
}

double Arctg1(double x, double ε) {
	double a = 0,s=1;
	bool f = 1;
	for (int i = 1;; i = i + 2)
	{
		if (f == 0) {
			f = 1;
			a += xstepeni(x, i) / i;
		}
		else {
			f = 0;
			a -= xstepeni(x, i) / i;
		}
		

		if (x - a < x - s) {

			s = a;
			if (ε > a) {


				return	a;
				break;
			}
		}
		

	}
}
/*

double arctg(double x) {
	
}
*/
int main()
{
	double x, ε;
	cin >> x >> ε;
	cout << Arctg1( x, ε);
	system("pause");
	return	0;
}